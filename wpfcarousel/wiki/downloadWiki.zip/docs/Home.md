**Project Description**
A Carousel Control for WPF that includes the ability to specify z-tilt angle (horizontal-to-vertical carousels), perspective tilt angle (to make the objects in rear easier to see), and item location-based opacity and size.

This is the WPF (3.5) version of a carousel selection control I originally created for a Silverlight class.  It also allows handlers to be attached when a carousel item is selected.

![](Home_http://www.murtaya.com/Mike/CodePlex/WPFCarousel1.jpg)
![](Home_http://www.murtaya.com/Mike/CodePlex/WPFCarousel2.jpg)

Any FrameworkElement object can be used as a carousel item; in fact you can even have carousels inside of carousels (which is what I used in my Silverlight class project).

For examples of this control in action (at least the Silverlight 3 version), see the following pages:
* [http://www.murtaya.com/Mike/RaceGame/RaceGame.html](http://www.murtaya.com/Mike/RaceGame/RaceGame.html)
	* Includes a carousel of carousels
	* Includes an auto-scroll carousel
![](Home_http://www.murtaya.com/Mike/CodePlex/CarouselColor.jpg)
![](Home_http://www.murtaya.com/Mike/CodePlex/CarouselScores.jpg)
 
* [http://www.mymurtaya.com](http://www.mymurtaya.com)
	* Includes an auto-scroll carousel
	* Includes a diagonal carousel
	* Includes many other carousel examples
![](Home_http://www.murtaya.com/Mike/CodePlex/CarouselMultiple.jpg)


This solution also includes examples of an UIAutomation test that can drive the carousel.  Since there is no direct UIAutomation patterns implemented yet for this control, a mouse helper is used to select specific controls.
